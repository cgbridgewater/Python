from flask import Flask
from flask_app.controllers import usersController

app = Flask(__name__)
app.secret_key = "mums the word"