from pprint import pprint
from flask_app import app
from flask import render_template, request, redirect
from flask_app.models.favorite import Favorite