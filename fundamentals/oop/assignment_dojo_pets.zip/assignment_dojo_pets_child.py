from assignment_dojo_pets_parent import cat



print('''
(input page below)
''')
print(cat.name)
cat.eat()